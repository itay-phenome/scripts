#!/usr/bin/env python3
"""
RDS Weekly Backup Checker — Phenome Networks
Scans S3 buckets for weekly RDS dump backups and outputs a JSON report
compatible with the HTML backup verification dashboard.

Usage:
    python backup_checker.py                        # uses buckets.json in same dir
    python backup_checker.py --config /path/to/buckets.json
    python backup_checker.py --output report.json   # custom output path
    python backup_checker.py --profile my-aws-profile
    python backup_checker.py --min-size-mb 50       # flag files smaller than 50 MB
"""

import boto3
import json
import argparse
import sys
from datetime import datetime, timezone
from pathlib import Path
from botocore.exceptions import ClientError, NoCredentialsError

# ── defaults ────────────────────────────────────────────────────────────────
DEFAULT_CONFIG = Path(__file__).parent / "buckets.json"
DEFAULT_OUTPUT = Path(__file__).parent / "backup_report.json"
DEFAULT_MIN_SIZE_MB = 100          # files smaller than this → "suspect"
DATE_FORMAT = "%Y-%m-%d"           # expected subfolder date format


# ── helpers ──────────────────────────────────────────────────────────────────

def get_iso_week(dt: datetime) -> str:
    iso = dt.isocalendar()
    return f"W{iso[1]:02d} / {iso[0]}"


def bytes_to_human(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"


def find_latest_date_folder(s3, bucket: str, prefix: str) -> str | None:
    """
    List all 'directories' under prefix and return the one with the
    most recent date name (YYYY-MM-DD). Returns None if none found.
    """
    prefix = prefix.rstrip("/") + "/"
    paginator = s3.get_paginator("list_objects_v2")
    folders = []

    for page in paginator.paginate(Bucket=bucket, Prefix=prefix, Delimiter="/"):
        for cp in page.get("CommonPrefixes", []):
            folder = cp["Prefix"]                  # e.g. rds_weekly_backup/2026-05-09/
            name = folder.rstrip("/").split("/")[-1]
            try:
                datetime.strptime(name, DATE_FORMAT)
                folders.append(name)
            except ValueError:
                pass                               # skip non-date folders

    if not folders:
        return None
    return sorted(folders)[-1]                     # latest date lexicographically


def check_backup(s3, bucket: str, prefix: str, min_size_bytes: int) -> dict:
    """
    Check the latest date subfolder under bucket/prefix.
    Returns a result dict with status, size, date, file_count, path.
    """
    result = {
        "status": "missing",
        "size": "",
        "size_bytes": 0,
        "backupDate": "",
        "file_count": 0,
        "path": "",
        "notes": "",
    }

    try:
        latest_date = find_latest_date_folder(s3, bucket, prefix)
        if not latest_date:
            result["notes"] = f"No date folders found under s3://{bucket}/{prefix}"
            return result

        full_prefix = prefix.rstrip("/") + "/" + latest_date + "/"
        result["path"] = f"s3://{bucket}/{full_prefix}"
        result["backupDate"] = latest_date

        # list all objects in that date folder
        paginator = s3.get_paginator("list_objects_v2")
        objects = []
        for page in paginator.paginate(Bucket=bucket, Prefix=full_prefix):
            objects.extend(page.get("Contents", []))

        # filter out zero-byte "folder" objects
        files = [o for o in objects if o["Size"] > 0]
        result["file_count"] = len(files)

        if not files:
            result["notes"] = "Folder exists but contains no files"
            return result

        total_bytes = sum(o["Size"] for o in files)
        result["size_bytes"] = total_bytes
        result["size"] = bytes_to_human(total_bytes)

        if total_bytes < min_size_bytes:
            result["status"] = "suspect"
            result["notes"] = f"Total size {bytes_to_human(total_bytes)} is below threshold ({bytes_to_human(min_size_bytes)})"
        else:
            result["status"] = "ok"

    except ClientError as e:
        code = e.response["Error"]["Code"]
        if code in ("NoSuchBucket", "AccessDenied", "AllAccessDisabled"):
            result["notes"] = f"S3 error: {code}"
        else:
            result["notes"] = f"S3 error: {e}"

    return result


# ── main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="RDS S3 backup checker")
    parser.add_argument("--config",   default=str(DEFAULT_CONFIG),  help="Path to buckets.json")
    parser.add_argument("--output",   default=str(DEFAULT_OUTPUT),  help="Output JSON path")
    parser.add_argument("--profile",  default=None,                 help="AWS profile name")
    parser.add_argument("--region",   default="us-east-1",          help="Default AWS region")
    parser.add_argument("--min-size-mb", type=int, default=DEFAULT_MIN_SIZE_MB,
                        help="Minimum expected backup size in MB (default: 100)")
    args = parser.parse_args()

    config_path = Path(args.config)
    if not config_path.exists():
        print(f"[ERROR] Config file not found: {config_path}", file=sys.stderr)
        sys.exit(1)

    if config_path.suffix.lower() in (".xlsx", ".xlsm"):
        config = load_config_xlsx(config_path)
    else:
        with open(config_path) as f:
            config = json.load(f)

    customers: list = config.get("customers", [])
    reviewer: str   = config.get("reviewer", "")
    if not customers:
        print("[ERROR] No customers defined in config.", file=sys.stderr)
        sys.exit(1)

    min_size_bytes = args.min_size_mb * 1024 * 1024

    # AWS session
    try:
        session = boto3.Session(profile_name=args.profile, region_name=args.region)
        s3 = session.client("s3")
        # quick credential check
        s3.list_buckets()
    except NoCredentialsError:
        print("[ERROR] No AWS credentials found. Configure ~/.aws/credentials or set env vars.", file=sys.stderr)
        sys.exit(1)

    now = datetime.now(timezone.utc)
    report_date = now.strftime(DATE_FORMAT)
    iso = now.isocalendar()
    report_week = f"W{iso[1]:02d} / {iso[0]}"

    rows = []
    total = len(customers)

    print(f"\n{'─'*60}")
    print(f"  RDS Backup Checker — {report_date}  {report_week}")
    print(f"  Checking {total} environments  |  min size: {args.min_size_mb} MB")
    print(f"{'─'*60}\n")

    for i, customer in enumerate(customers, 1):
        name   = customer.get("name", f"Customer {i}")
        bucket = customer.get("bucket", "").lstrip("s3://").split("/")[0]
        prefix = customer.get("prefix", "").strip("/")

        if not bucket or not prefix:
            print(f"  [{i:02d}/{total}]  {name:<40}  SKIPPED (no bucket/prefix configured)")
            rows.append({
                "name": name, "group": customer.get("group", ""),
                "status": "na", "size": "", "backupDate": "",
                "notes": "Not configured", "path": ""
            })
            continue

        print(f"  [{i:02d}/{total}]  {name:<40}", end="  ", flush=True)
        result = check_backup(s3, bucket, prefix, min_size_bytes)

        icon = {"ok": "✓", "missing": "✗", "suspect": "⚠", "na": "—"}.get(result["status"], "?")
        print(f"{icon}  {result['status'].upper():<8}  {result['size']:<10}  {result['backupDate']}")
        if result["notes"]:
            print(f"           └─ {result['notes']}")

        rows.append({
            "name":       name,
            "group":      customer.get("group", ""),
            "status":     result["status"],
            "size":       result["size"],
            "backupDate": result["backupDate"],
            "notes":      result["notes"],
            "path":       result["path"],
        })

    # summary
    ok      = sum(1 for r in rows if r["status"] == "ok")
    missing = sum(1 for r in rows if r["status"] == "missing")
    suspect = sum(1 for r in rows if r["status"] == "suspect")
    na      = sum(1 for r in rows if r["status"] == "na")

    print(f"\n{'─'*60}")
    print(f"  ✓ OK: {ok}   ✗ Missing: {missing}   ⚠ Suspect: {suspect}   — N/A: {na}")
    print(f"{'─'*60}\n")

    # write output JSON
    output = {
        "reportDate":  report_date,
        "reportWeek":  report_week,
        "reviewer":    reviewer,
        "generatedAt": now.isoformat(),
        "summary":     {"total": total, "ok": ok, "missing": missing, "suspect": suspect, "na": na},
        "rows":        rows,
    }

    out_path = Path(args.output)
    with open(out_path, "w") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    print(f"  Report saved → {out_path}\n")


if __name__ == "__main__":
    main()


# ── Excel config loader (replaces JSON loader when --config is .xlsx) ─────

def load_config_xlsx(path: Path) -> dict:
    """Read backup config from Excel file (backup_config.xlsx)."""
    try:
        import openpyxl
    except ImportError:
        print("[ERROR] openpyxl not installed. Run: pip install openpyxl", file=sys.stderr)
        sys.exit(1)

    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb["Backup Config"]

    customers = []
    for row in ws.iter_rows(min_row=3, values_only=True):
        idx, name, group, bucket, prefix, s3_uri = (list(row) + [None]*6)[:6]
        if not name:
            continue
        bucket  = str(bucket).strip()  if bucket  else ""
        prefix  = str(prefix).strip()  if prefix  else ""
        group   = str(group).strip()   if group   else ""
        customers.append({"name": name, "group": group, "bucket": bucket, "prefix": prefix})

    return {"reviewer": "Itay", "customers": customers}
